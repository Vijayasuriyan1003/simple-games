const cells = document.querySelectorAll(".cell");
const message = document.getElementById("message");
const newGameButton = document.getElementById("newGameButton");
const restartGameButton = document.getElementById("restartGameButton");
const board = document.getElementById("board");

let currentPlayer = "X";
let gameBoard = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;

function handleCellClick(e) {
    const cell = e.target;
    const cellIndex = cell.id;

    if (gameBoard[cellIndex] === "" && gameActive) {
        gameBoard[cellIndex] = currentPlayer;
        cell.textContent = currentPlayer;
        cell.style.backgroundColor = currentPlayer === "X" ? "#e74c3c" : "#3498db";

        if (checkWin()) {
            message.textContent = `Player ${currentPlayer} wins!`;
            gameActive = false;
            showNewGameButton();
            highlightWinningCombo();
            showModal(`Player ${currentPlayer} wins!`);
        } else if (checkDraw()) {
            message.textContent = "It's a draw!";
            gameActive = false;
            showNewGameButton();
            showModal("It's a draw!");
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
            message.textContent = `Player ${currentPlayer}'s turn`;
        }
    }
}

function checkWin() {
    const winCombos = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];

    return winCombos.some(combo => {
        if (combo.every(index => gameBoard[index] === currentPlayer)) {
            return true;
        }
    });
}

function checkDraw() {
    return gameBoard.every(cell => cell !== "");
}

function showNewGameButton() {
    newGameButton.style.display = "block";
}

function highlightWinningCombo() {
    const winCombos = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];

    for (const combo of winCombos) {
        const [a, b, c] = combo;
        if (gameBoard[a] === currentPlayer && gameBoard[b] === currentPlayer && gameBoard[c] === currentPlayer) {
            cells[a].classList.add("winner");
            cells[b].classList.add("winner");
            cells[c].classList.add("winner");
        }
    }
}

function startNewGame() {
    gameBoard = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;
    currentPlayer = "X";
    cells.forEach(cell => {
        cell.textContent = "";
        cell.style.backgroundColor = "#ddd";
        cell.classList.remove("winner");
    });
    message.textContent = "Player X's turn";
    newGameButton.style.display = "none";
    restartGameButton.style.display = "none";
}

function restartGame() {
    gameBoard = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;
    currentPlayer = "X";
    cells.forEach(cell => {
        cell.textContent = "";
        cell.style.backgroundColor = "#ddd";
        cell.classList.remove("winner");
    });
    message.textContent = "Player X's turn";
    newGameButton.style.display = "none";
    restartGameButton.style.display = "none";
}

function showModal(result) {
    const resultModal = document.getElementById("resultModal");
    const resultText = document.getElementById("resultText");

    resultText.textContent = result;
    resultModal.style.display = "block";

    const playAgainButton = document.getElementById("playAgainButton");
    playAgainButton.addEventListener("click", function () {
        resultModal.style.display = "none";
        startNewGame();
    });

    const closeModal = document.getElementById("closeModal");
    closeModal.addEventListener("click", function () {
        resultModal.style.display = "none";
    });
}

cells.forEach(cell => cell.addEventListener("click", handleCellClick));
newGameButton.addEventListener("click", startNewGame);
restartGameButton.addEventListener("click", restartGame);
