document.addEventListener('DOMContentLoaded', function () {
    const cards = ['♦', '♦','♣','♣', '♥','♥','♠','♠','☯','☯','☀','☀', '♛','♛', '♖','♖'];
    let flippedCards = [];
    let matchedCards = [];

    function shuffle(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    function createCard(cardValue) {
        const card = document.createElement('div');
        card.classList.add('card');
        card.dataset.value = cardValue;
        card.innerHTML = cardValue;
        card.addEventListener('click', flipCard);
        return card;
    }

    function createBoard() {
        const memoryGame = document.querySelector('.memory-game');
        shuffle(cards);

        for (let cardValue of cards) {
            const card = createCard(cardValue);
            memoryGame.appendChild(card);
        }
    }

    function flipCard() {
        if (flippedCards.length < 2 && !this.classList.contains('flipped')) {
            this.classList.add('flipped');
            flippedCards.push(this);

            if (flippedCards.length === 2) {
                setTimeout(checkMatch, 500);
            }
        }
    }
 function startTimer() {
    timer = setInterval(function () {
        seconds++;
        document.getElementById('timer').innerText = formatTime();
    }, 1000);
}
    function checkMatch() {
        const [card1, card2] = flippedCards;

        if (card1.dataset.value === card2.dataset.value) {
            card1.classList.add('matched');
            card2.classList.add('matched');
            matchedCards.push(card1, card2);

            if (matchedCards.length === cards.length) {
                alert('Congratulations! You cracked this match.');
                startNewGame(); // Start a new game on completion
            }
        } else {
            card1.classList.remove('flipped');
            card2.classList.remove('flipped');
        }

        flippedCards = [];
    }

    function restartGame() {
        const memoryGame = document.querySelector('.memory-game');
        memoryGame.innerHTML = ''; // Clear the existing cards
        matchedCards = [];
        createBoard(); // Create a new board
    }

    function startNewGame() {
        restartGame(); // Simply call restartGame to start a new game
    }

    // Event listener for the restart button
    const restartButton = document.getElementById('restart-button');
    restartButton.addEventListener('click', restartGame);

    createBoard();
});
